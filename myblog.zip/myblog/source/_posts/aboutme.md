---
title: aboutme
date: 2021-05-19 23:43:22
tags:
- aboutme
category:
- 其他
---

作者：akari
爱好：篮球，游戏，编程
联系方式：
email：3081095099@qq.com
qq: 3081095099
相关博客链接：
csdn: https://blog.csdn.net/qq_50640292
GitHub：https://github.com/akari-yd
简书：https://blog.csdn.net/qq_50640292